# UltimateNotePad frontend refactoring (2026-11-20)

- `static/js/app.js`: search, create/delete dialogs and JST display share one initialization and common dialog utilities.
- `static/js/autosave.js`: original autosave queue, retries, offline handling and unsaved-change warning retained unchanged.
- `static/css/app.css`: style.css, animations.css and editor-fit.css concatenated in their exact previous cascade order.
- `legacy/css/layout-compact.css`: previously unused stylesheet retained for reference.
- `templates/index.html`: one CSS link and two JS links; redundant inline create handler removed.
- `app.py`, the database and study exercises: untouched.

Source: https://github.com/ayuyu0907/UltimateNotePad
Note: Original timestamp conversion assumes stored date values are UTC.
