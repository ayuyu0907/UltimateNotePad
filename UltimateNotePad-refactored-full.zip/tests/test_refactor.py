"""Run with python3 -m unittest discover -s tests after extracting the package."""
import importlib.util
from pathlib import Path
import tempfile
import unittest
from zipfile import ZipFile

SCRIPT = Path(__file__).resolve().parents[1] / 'refactor.py'
spec = importlib.util.spec_from_file_location('unp_refactor', SCRIPT)
refactor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(refactor)


class RefactorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / 'static/js').mkdir(parents=True)
        (self.root / 'static/css').mkdir(parents=True)
        (self.root / 'templates').mkdir(parents=True)
        (self.root / 'app.py').write_text('print("Flask unchanged")\n')
        (self.root / 'data').mkdir()
        (self.root / 'data/notes.db').write_bytes(b'PRIVATE DB')
        self.css_sources = {
            'style.css': '.thing {color: red;}\n',
            'animations.css': '.thing {color: blue;}\n',
            'editor-fit.css': '.thing {color: green;}\n',
        }
        for n, content in self.css_sources.items():
            (self.root / 'static/css' / n).write_text(content)
        (self.root / 'static/css/layout-compact.css').write_text('old css')
        for name in refactor.EXPECTED_JS:
            (self.root / 'static/js' / name).write_text('// legacy ' + name)
        (self.root / 'templates/index.html').write_text('''<!doctype html><head>
<link rel="stylesheet" href="{{ url_for('static', filename='css/style.css') }}">
<link rel="stylesheet" href="{{ url_for('static', filename='css/animations.css') }}">
<link rel="stylesheet" href="{{ url_for('static', filename='css/editor-fit.css') }}">
</head><body>
<form class="note-edit-form"><input name="q"><select name="sort"></select></form>
<script src="{{ url_for('static', filename='js/date-jst.js') }}"></script>
<script src="{{ url_for('static', filename='js/autosave.js') }}"></script>
<script src="{{ url_for('static', filename='js/create-modal.js') }}"></script>
<script src="{{ url_for('static', filename='js/delete-modal.js') }}"></script>
<script src="{{ url_for('static', filename='js/search-ui.js') }}" defer></script>
<script>
  document.querySelector("#welcome-create-note")
    ?.addEventListener("click", () => {
      document.querySelector("#create-note-open")?.click();
    });
</script>
</body>''')

    def test_apply_and_backup_and_full_archive(self):
        base = SCRIPT.parent
        refactor.refactor(self.root, base)
        html = (self.root / 'templates/index.html').read_text()
        self.assertEqual(refactor.CSS_RE.findall(html), ['app.css'])
        self.assertEqual(refactor.JS_RE.findall(html), ['app.js', 'autosave.js'])
        self.assertNotIn('?.addEventListener("click"', html)
        combined = (self.root / 'static/css/app.css').read_text()
        self.assertLess(combined.index('color: red'), combined.index('color: blue'))
        self.assertLess(combined.index('color: blue'), combined.index('color: green'))
        self.assertTrue((self.root / 'legacy/css/layout-compact.css').exists())
        self.assertFalse((self.root / 'static/js/create-modal.js').exists())
        self.assertTrue((self.root / 'static/js/autosave.js').exists())
        self.assertTrue((self.root / 'data/notes.db').exists())
        archives = list((self.root / '.refactor-backups').glob('*.zip'))
        self.assertEqual(len(archives), 1)
        with ZipFile(archives[0]) as z:
            self.assertIn('templates/index.html', z.namelist())
            self.assertIn('static/css/style.css', z.namelist())
        with ZipFile(self.root / 'UltimateNotePad-refactored-full.zip') as z:
            self.assertIn('app.py', z.namelist())
            self.assertIn('static/css/app.css', z.namelist())
            self.assertIn('static/js/app.js', z.namelist())
            self.assertNotIn('data/notes.db', z.namelist())
        # Reapplying must not mutate or lose assets.
        refactor.refactor(self.root, base)
        self.assertEqual(len(list((self.root / '.refactor-backups').glob('*.zip'))), 1)

    def test_dry_run(self):
        refactor.refactor(self.root, SCRIPT.parent, True)
        self.assertFalse((self.root / 'static/css/app.css').exists())
        self.assertFalse((self.root / '.refactor-backups').exists())

    def test_unrecognized_structure_fails_before_write(self):
        p = self.root / 'templates/index.html'
        p.write_text(p.read_text().replace('editor-fit.css', 'unknown.css'))
        with self.assertRaises(RuntimeError):
            refactor.refactor(self.root, SCRIPT.parent)
        self.assertFalse((self.root / '.refactor-backups').exists())


if __name__ == '__main__':
    unittest.main()
